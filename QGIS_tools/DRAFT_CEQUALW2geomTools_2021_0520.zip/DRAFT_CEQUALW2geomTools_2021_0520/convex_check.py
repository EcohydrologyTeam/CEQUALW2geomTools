import processing
root = QgsProject.instance().layerTreeRoot()


#INPUT: Path to W2 segments saved shape file
pth_Segments = "G:/GitHub/CEQUALW2geomTools/QGIS_tools/TEMP_SegmentsB.shp"


#Create Convex Hull Polygon
params = {
	'INPUT': pth_Segments,
	'OUTPUT': 'TEMPORARY_OUTPUT'}

result_Segments_CnxHull = processing.run("native:convexhull", params)
result_layer_Segments_CnxHull = result_Segments_CnxHull['OUTPUT']
QgsProject.instance().addMapLayer(result_layer_Segments_CnxHull)


#Assign Geometry Attributes to W2 segments
params = {
	'CALC_METHOD': 0,
	'INPUT': pth_Segments,
	'OUTPUT': 'TEMPORARY_OUTPUT'}
	
result_Segments = processing.run("qgis:exportaddgeometrycolumns", params)
result_layer_Segments = result_Segments['OUTPUT']
QgsProject.instance().addMapLayer(result_layer_Segments)


#Perform Table Join between W2 segements and Convex Hull W2 segments
params = {
	'DISCARD_NONMATCHING': False,
	'FIELD': 'order_id',
	'FIELDS_TO_COPY': [],
	'FIELD_2': 'order_id',
	'INPUT': result_layer_Segments,
	'INPUT_2': result_layer_Segments_CnxHull,
	'METHOD': 1,
	'OUTPUT': 'TEMPORARY_OUTPUT',
	'PREFIX': 'cnx_'}

result_Segments_joined = processing.run("native:joinattributestable", params)
result_layer_Segments_joined = result_Segments_joined['OUTPUT']
QgsProject.instance().addMapLayer(result_layer_Segments_joined)


#Create field for convex polygon check
params = {
	'FIELD_LENGTH': 10,
	'FIELD_NAME': 'IsConvex',
	'FIELD_PRECISION': 10,
	'FIELD_TYPE': 1,
	'FORMULA': 'if( round( \"perimeter\", 4) - round( \"cnx_perimeter\", 4) = 0, 1, 0)',
	'INPUT': result_layer_Segments_joined,
	'OUTPUT': 'TEMPORARY_OUTPUT'}

result_Segments_joined_chck = processing.run("native:fieldcalculator", params)
result_layer_Segments_joined_chck = result_Segments_joined_chck['OUTPUT']
QgsProject.instance().addMapLayer(result_layer_Segments_joined_chck)


